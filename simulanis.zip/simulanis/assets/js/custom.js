
jQuery('#featuredCourse').owlCarousel({
    rtl:false,
    loop:true,
    margin:10,
    dots: false,
    nav:true,
    autoplay:true,
    autoplayTimeout:10000,
    autoplayHoverPause:false,
    smartSpeed: 3000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:5
        }
    }
});

jQuery('#popular_among').owlCarousel({
    rtl:false,
    loop:true,
    margin:10,
    dots: false,
    nav:true,
    autoplay:true,
    autoplayTimeout:13000,
    autoplayHoverPause:false,
    smartSpeed: 3000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:5
        }
    }
});

